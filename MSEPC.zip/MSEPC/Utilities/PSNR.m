%
% function r = PSNR(x1, x2)
%
%   This function returns the PSNR between images x1 and x2.

function r = PSNR(x1, x2)

error = x1 - x2;

r = 10 * log10(255^2 / mean(error(:).^2));
