function totalbits_Huffman = calculate_totalbits_Huffman (image)

% calculate the frequency of each pixel
[frequency, pixelValue] = imhist(image());

% sum all the frequencies
tf = sum(frequency);

% calculate the frequency of each pixel
probability = frequency ./ tf ;

% create a dictionary
dict = huffmandict(pixelValue,probability);

% get the image pixels in 1D array
imageOneD = image(:);

% encoding
testVal = imageOneD;

encodedVal = huffmanenco(testVal, dict);

totalbits_Huffman = length(encodedVal);

end







