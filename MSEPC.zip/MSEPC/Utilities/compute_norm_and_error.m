function [norm_x, norm_xe, relative_error] = compute_norm_and_error(x, y)
% Compute the norm of original and estimated image patches and the relative error
% Input parameters:
%   x: Original image patch matrix, each column is an image patch
%   y: Estimated image patch matrix, each column is an image patch
% Output parameters:
%   norm_x: Norm vector of original image patches
%   norm_xe: Norm vector of estimated image patches
%   relative_error: Relative error vector

% Validate input
if nargin < 2
    error('Two input arguments are required: x and y');
end

% Check if dimensions are consistent
if size(x, 2) ~= size(y, 2)
    error('x and y must have the same number of columns');
end

% Get the number of columns
col_y = size(y, 2);

% Preallocate memory
norm_x = zeros(1, col_y);
norm_xe = zeros(1, col_y);
relative_error = zeros(1, col_y);

% Compute norms and relative error
for i = 1:col_y
    norm_x(i) = norm(x(:, i));         % Norm of each original patch
    norm_xe(i) = norm(y(:, i));        % Norm of each estimated patch
    
    % Avoid division by zero
    if norm_x(i) > 0
        relative_error(i) = abs(norm_x(i) - norm_xe(i)) / norm_x(i);  % Compute relative error
    else
        relative_error(i) = 0;  % If the original norm is 0, set relative error to 0
    end
end
end