function [x_mean_estimation] = estimate_image_mean(norm_xe, N, M, matrix_type)
% Function to estimate the mean of the image
% Input parameters:
%   norm_xe: Norm vector of estimated sub-images
%   N: Dimension of each original image sub-block
%   M: Number of measurements
%   matrix_type: Measurement matrix type ('orth' or 'gaussian')
% Output parameters:
%   x_mean_estimation: Estimated image mean vector

% Validate input parameters
if nargin < 4
    error('Four input arguments are required: norm_xe, N, M, matrix_type');
end

% Ensure norm_xe is a row vector
if iscolumn(norm_xe)
    norm_xe = norm_xe';
end

% Validate matrix type
if ~(strcmpi(matrix_type, 'orth') || strcmpi(matrix_type, 'gaussian'))
    error('Unsupported matrix type. Please choose "orth" or "gaussian"');
end

% Select different estimation formulas based on matrix type
switch lower(matrix_type)
    case 'orth'
        % Estimation formula for orthogonal matrix: sqrt(N/M) * norm_xe / sqrt(N) = norm_xe / sqrt(M)
        x_mean_estimation = norm_xe / sqrt(M);
        
    case 'gaussian'
        % Estimation formula for Gaussian random matrix: norm_xe / sqrt(N)
        x_mean_estimation = norm_xe / sqrt(N);
        
    otherwise
        error('Unsupported matrix type. Please choose "orth" or "gaussian"');
end
end