function Phi = generate_measurement_matrix_simple(N, M, matrix_type)
% Simplified version of generating measurement matrix
% Input parameters:
%   N: Dimension of original signal
%   M: Dimension of measurement
%   matrix_type: Matrix type ('orth' or 'gaussian')
%   seed: Random number seed (optional)
% Output parameters:
%   Phi: Measurement matrix of size M×N

% Generate measurement matrix based on matrix type
switch lower(matrix_type)
    case 'orth'
        % Orthogonal matrix
        Phi_full = orth(randn(N, N))';
        Phi = Phi_full(1:M, :);
        
    case 'gaussian'
        % Gaussian random matrix
        Phi = (1 / sqrt(M)) * randn(M, N);
        
    otherwise
        error('Unsupported matrix type. Please choose "orth" or "gaussian"');
end
end