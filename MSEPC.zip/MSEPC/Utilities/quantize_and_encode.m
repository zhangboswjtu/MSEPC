function [y_diff_quan, y_diff_sq, rate_Huffman] = quantize_and_encode(y_diff, quantizer_bitdepth_CS, row, col)
% Quantization, encoding, and bit rate calculation
% Input parameters:
%   y_diff: Difference image matrix
%   quantizer_bitdepth_CS: Quantization bit depth
%   row: Number of image rows
%   col: Number of image columns
% Output parameters:
%   y_diff_quan: Quantized difference
%   y_diff_sq: Inverse-quantized difference
%   rate_Huffman: Bit rate of Huffman encoding

% Validate input parameters
if nargin < 4
    error('Four input arguments are required: y_diff, quantizer_bitdepth_CS, row, col');
end

if quantizer_bitdepth_CS <= 0
    error('Quantization bit depth must be a positive integer');
end

if isempty(y_diff)
    error('Input difference matrix cannot be empty');
end

% Get the range of difference values
y_max = max(y_diff(:));
y_min = min(y_diff(:));

% fprintf('Difference range: [%.4f, %.4f], Range: %.4f\n', y_min, y_max, y_max - y_min);

% Calculate quantization step size
q = (y_max - y_min) / (2^quantizer_bitdepth_CS);
% fprintf('Quantization step size: %.6f (based on bit depth %d)\n', q, quantizer_bitdepth_CS);

% Quantization
y_diff_quan = round(y_diff / q);

% Huffman encoding
% Note: Need to convert y_diff_quan to int8 type, as Huffman encoding typically processes integers
totalbits_Huffman = calculate_totalbits_Huffman(int8(y_diff_quan));

% Calculate bit rate
rate_Huffman = totalbits_Huffman / (row * col);

% Inverse quantization
y_diff_sq = y_diff_quan * q;
end